2012 07 05 uxian
new plugin should be placed in this directory, and remember add the name of it to __all__ list in this __init__.py.