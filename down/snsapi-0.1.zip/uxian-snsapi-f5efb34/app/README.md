app
====

How to deploy?
----

It's very simple to have a test of apps in this folder:
   * Clone the whole git repository. 
   * Make a symbolic link of 'snsapi' and other essential 
   subdirectoreis to the app working directory. 
   i.e. (from the path of this document) 
```
cd forwarder
ln -s ../../snsapi
ln -s ../../auxiliary
```
   * Refer to the app's document for the commands. 

List of Apps
----

Here's a list of apps. 
Please refer to their own directory for detailed information. 
   * forwarder
