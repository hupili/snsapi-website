third
====

This folder contains third-party libraries. 
We do not guarantee an entire package of the 
original release is present in this folder. 
Without special reasons, only involved 
files are put here. 
If this operation make essential LICENSE
information missing, please refer to original 
releases. 

We leave a pointer for each library:
   * 'feedparser.py'. 
   [http://code.google.com/p/feedparser/](http://code.google.com/p/feedparser/)
   * 'PyRSS2Gen.py'. 
   [http://www.dalkescientific.com/Python/PyRSS2Gen.html](http://www.dalkescientific.com/Python/PyRSS2Gen.html)
   * 'pyDes.py'. 
   [http://twhiteman.netfirms.com/des.html](http://twhiteman.netfirms.com/des.html)
   * 'oauth.py'. 
   [link-missing](link-missing)
