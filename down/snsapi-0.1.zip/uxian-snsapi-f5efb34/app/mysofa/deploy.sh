#!/bin/bash
#automatic deploy scripts for app
#make sure the snsapi project directory tree
#is not modified before you run this script

ln -s ../../snsapi .
ln -s ../../conf .

exit 0 
