# -*- coding: utf-8 -*-

'''
Just testing new line delimiter
'''