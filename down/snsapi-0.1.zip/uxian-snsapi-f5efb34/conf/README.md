Configuration
====

File description
----

   * 'conf.json' : for backward support of previous conf style. 
   It is staged for retiring after code review and merge 
   this branch to master. 
   * 'channel.json' : new configuration, a realization of 
   SinaAPI and RSSAPI. 
   * '.example' : the example file of configs. 
   Generally, you should copy them to the corresponding
   file without '.example' suffix and fill in your 
   information. 
